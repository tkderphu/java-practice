package code_ptit.practice;

public class BinaryTextWordSet extends TextWordSet {

}
