package code_ptit.pair;

import java.io.Serializable;

public class Pair implements Serializable, Comparable<Pair> {
    private int first;
    private int second;

    public Pair(int first, int second) {
        this.first = first;
        this.second = second;
    }

    public int getFirst() {
        return first;
    }

    public int getSecond() {
        return second;
    }

    @Override
    public int compareTo(Pair o) {
        return this.first - o.first;
    }

    @Override
    public boolean equals(Object obj) {
        if(obj instanceof Pair) {
            Pair pair = (Pair) obj;
            return pair.first == this.first && pair.second == this.second;
        }
        return false;
    }

    @Override
    public String toString() {
        return "(" + first + ", " + second + ")";
    }
}
