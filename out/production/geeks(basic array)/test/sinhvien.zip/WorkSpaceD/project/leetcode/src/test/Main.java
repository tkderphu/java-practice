package test;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public class Main {
    public static void main(String[] args) throws IOException, ClassNotFoundException {
        ObjectInputStream ois = new ObjectInputStream(new FileInputStream("DATA.in"));
        ArrayList<Pair> pairs = (ArrayList<Pair>) ois.readObject();
        Map<String, Integer> map = new HashMap<>();
        Collections.sort(pairs);
        for(int i = 0; i < pairs.size(); i++) {
            Pair pair = pairs.get(i);
            if(pair.getFirst() < pair.getSecond()) {
                if(!map.containsKey(pair.toString())) {
                    System.out.println(pair);
                    map.put(pair.toString(), 1);
                }
            }
        }
    }
}
