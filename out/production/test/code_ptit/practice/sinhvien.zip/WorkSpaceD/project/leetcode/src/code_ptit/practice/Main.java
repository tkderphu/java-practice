package code_ptit.practice;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.Stack;

public class Main {
    public static void main(String[] args) throws IOException {
        Scanner input = new Scanner(System.in);
        int numberOfStudent = input.nextInt();
        int numberOfScholarship = input.nextInt();
        input.nextLine();
        List<Student> students = new ArrayList<>();
        Map<String, Integer> map = new HashMap<>();

        for (int i = 0; i < numberOfStudent; i++) {
            String name = input.nextLine();
            double gpa = input.nextDouble();
            int cultivation = input.nextInt();
            input.nextLine();
            Student student = new Student(i + 1, name, gpa, cultivation);
            students.add(student);
        }
        for (int i = 0; i < numberOfStudent; i++) {
            Student student = students.get(i);
            if (i == 0) {
                System.out.println(student.getName() + ": " + student.receivedScholarship());
                numberOfScholarship--;
            } else {
                if (student.getGpa().compareTo(students.get(i - 1).getGpa()) == 0) {
                    System.out.println(student.getName() + ": " + student.receivedScholarship());
                } else {
                    if (numberOfScholarship != 0) {
                        System.out.println(student.getName() + ": " + student.receivedScholarship());
                        numberOfScholarship --;
                    } else {
                        System.out.println(student.getName() + ": " + "KHONG");
                    }
                }
            }
        }

//        List<Student> sortedStudents = new ArrayList<>(students);
//        Collections.sort(sortedStudents, (s1, s2) -> {
//            return s2.getGpa().compareTo(s1.getGpa());
//        });
//        map.put(sortedStudents.get(0).getId(), 1);
//        for(int i = 1; i < numberOfStudent; i++) {
//            if(sortedStudents.get(i).getGpa().compareTo(sortedStudents.get(i - 1).getGpa()) == 0) {
//                map.put(sortedStudents.get(i).getId(), map.get(sortedStudents.get(i - 1).getId()));
//            } else {
//                map.put(sortedStudents.get(i).getId(), map.get(sortedStudents.get(i - 1).getId()) + 1);
//            }
//        }
//        for(Student student : students) {
//            if(map.get(student.getId()) <= numberOfScholarship) {
//                System.out.println(student.getName() + ": " + student.receivedScholarship());
//            } else {
//                System.out.println(student.getName() + ": " + "KHONG");
//            }
//        }

    }

}
