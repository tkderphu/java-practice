package code_ptit.danhsachsinhvien1.bao_hanh;

public class Product {
    private String id;
    private String name;
    private int price;
    private int warranty;

    public Product(String id, String name, int price, int warranty) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.warranty = warranty;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public int getPrice() {
        return price;
    }

    public int getWarranty() {
        return warranty;
    }
}
