package code_ptit.pair;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.lang.reflect.Array;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) throws IOException, ClassNotFoundException {
        ObjectInputStream ois = new ObjectInputStream(new FileInputStream("DATA.in"));
        ArrayList<Pair> pairs = (ArrayList<Pair>) ois.readObject();
        pairs.stream()
                .filter(pair -> pair.getFirst() < pair.getSecond())
                .distinct()
                .sorted()
                .forEach(System.out::println);
    }
}
