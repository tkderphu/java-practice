package code_ptit.danhsachsinhvien1.bao_hanh;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Bill implements Comparable<Bill>{
    private Customer customer;
    private Product product;
    private int quantity;
    private String buyDate;

    public Bill(Customer customer, Product product, int quantity, String buyDate) {
        this.customer = customer;
        this.product = product;
        this.quantity = quantity;
        this.buyDate = buyDate;
    }

    public int totalPrice() {
        return this.quantity * this.product.getPrice();
    }

    public String warrantyDateExpire() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        LocalDate buyDate = LocalDate.parse(this.buyDate, formatter);
        buyDate = buyDate.plusMonths(this.product.getWarranty() * 1);
        return buyDate.format(formatter);
    }

    @Override
    public String toString() {
        return customer.getId() + " " + customer.getName() + " " + customer.getAddress() + " " +
                product.getId() + " " + totalPrice() + " " + warrantyDateExpire();
    }

    @Override
    public int compareTo(Bill o) {
        if(this.warrantyDateExpire().compareTo(o.warrantyDateExpire()) == 0) {
            return this.customer.getId().compareTo(o.customer.getId());
        }
        return this.warrantyDateExpire().compareTo(o.warrantyDateExpire());
    }
}
