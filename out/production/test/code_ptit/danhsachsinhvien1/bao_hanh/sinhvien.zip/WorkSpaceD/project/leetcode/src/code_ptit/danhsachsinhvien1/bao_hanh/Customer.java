package code_ptit.danhsachsinhvien1.bao_hanh;

public class Customer {
    private String id;
    private String name;
    private String address;

    public Customer(int id, String name, String address) {
        this.id = String.format("KH%02d", id);
        this.name = name;
        this.address = address;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getAddress() {
        return address;
    }
}
