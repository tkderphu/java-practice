package code_ptit.danhsachsinhvien1.bao_hanh;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;

public class Main {
    public static void main(String[] args) throws FileNotFoundException {
        Scanner input = new Scanner(new File("MUAHANG.in"));
        int numPro = Integer.parseInt(input.nextLine());
        Map<String, Product> products = new HashMap<>();
        for(int i = 0; i < numPro; i++) {
            Product product = new Product(
                    input.nextLine(),
                    input.nextLine(),
                    Integer.parseInt(input.nextLine()),
                    Integer.parseInt(input.nextLine())
            );
            products.put(product.getId(), product);
        }
        int numCus = Integer.parseInt(input.nextLine());
        Map<String, Customer> customers = new HashMap<>();
        List<Bill> bills = new ArrayList<>();
        for(int i = 1; i <= numCus; i++) {
            String cusName = input.nextLine();
            String address = input.nextLine();
            Product product = products.get(input.nextLine());
            int quantity = Integer.parseInt(input.nextLine());
            String buyDate = input.nextLine();
            Customer customer = new Customer(i, cusName, address);
            Bill bill = new Bill(customer, product, quantity, buyDate);

            customers.put(customer.getId(), customer);
            bills.add(bill);
        }

        bills.stream()
                .sorted()
                .forEach(s -> System.out.println(s));


    }
}
